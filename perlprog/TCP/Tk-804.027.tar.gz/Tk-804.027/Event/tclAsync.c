#define TCL_EVENT_IMPLEMENT
#include "../pTk/tclAsync.c"

