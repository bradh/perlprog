#define TCL_EVENT_IMPLEMENT
#include "../pTk/tclNotify.c"
