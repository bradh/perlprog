#define TCL_EVENT_IMPLEMENT
#include "../pTk/tclEvent.c"
