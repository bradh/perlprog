#!/usr/bin/perl -w
use strict;
use Tkx;

use ConfiguratorProject;
use ConfiguratorCSV;
use ConfiguratorFile;


my $projectName;
my @project_param;
my @IP_address;
my @TCP_port;
my @process_list;
my @DLIP_mct_main_cfg;
#my @DLIP_mct_main_trc1;
#my @DLIP_mct_main_trc2;
my @TDL_ROUTER_tdl_router_main;
my @TDL_ROUTER_l16_param;
my @TDL_ROUTER_mids_registration;
my @TDL_ROUTER_standalone;
my @TDL_ROUTER_simple_if;
my @JREP_internal_parameters;
my @JREP_configuration_parameters;
my @JREP_parameters;
my @Supervisor_main;
my @Supervisor_dlip;
my @Supervisor_tdl_router;
my @Supervisor_jrep;
my @Supervisor_jrem;
my @Supervisor_tlcmgr;
my @Supervisor_osim;


ConfiguratorFile::init(		
							\$projectName,
							\@IP_address, 
							\@TCP_port, 
							\@process_list,
							\@DLIP_mct_main_cfg,
							#\@DLIP_mct_main_trc1,
							#\@DLIP_mct_main_trc2,
							\@TDL_ROUTER_tdl_router_main, 
							\@TDL_ROUTER_l16_param, 
							\@TDL_ROUTER_mids_registration,
							\@TDL_ROUTER_standalone,
							\@TDL_ROUTER_simple_if,
							\@JREP_internal_parameters,
							\@JREP_configuration_parameters,
							\@JREP_parameters,
							\@Supervisor_main,
							\@Supervisor_dlip,
							\@Supervisor_tdl_router,
							\@Supervisor_jrep,
							\@Supervisor_osim,
							\@Supervisor_tlcmgr,
							\@Supervisor_jrem
							);
							
# Main window Tak$e top and the bottom - now implicit top is in the middle
ConfiguratorProject::init(	
							\$projectName,
							\@project_param, 
							\@IP_address, 
							\@TCP_port, 
							\@process_list,
							\@DLIP_mct_main_cfg,
							#\@DLIP_mct_main_trc1,
							#\@DLIP_mct_main_trc2,
							\@TDL_ROUTER_tdl_router_main, 
							\@TDL_ROUTER_l16_param, 
							\@TDL_ROUTER_mids_registration,
							\@TDL_ROUTER_standalone,
							\@TDL_ROUTER_simple_if,
							\@JREP_internal_parameters,
							\@JREP_configuration_parameters,
							\@JREP_parameters,
							\@Supervisor_main,
							\@Supervisor_dlip,
							\@Supervisor_tdl_router,
							\@Supervisor_jrep,
							\@Supervisor_osim,
							\@Supervisor_tlcmgr,
							\@Supervisor_jrem
							);
















